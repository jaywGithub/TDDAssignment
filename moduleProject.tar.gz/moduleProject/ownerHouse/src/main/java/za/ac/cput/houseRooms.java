package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class houseRooms {
    public static int rooms(int r)throws Exception
    {
        return r;
    }
}
