package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class housePainted {
    public static char painted(char p)throws Exception
    {
        return p;
    }
}
