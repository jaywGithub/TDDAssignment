package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class houseValue {
    public static int value(int v)throws Exception
    {
        return v;
    }
}
