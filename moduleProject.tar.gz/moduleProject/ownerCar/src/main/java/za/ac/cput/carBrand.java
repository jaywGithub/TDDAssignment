package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class carBrand {
    public static String brand(String make) throws Exception
    {
        return make;
    }
}
