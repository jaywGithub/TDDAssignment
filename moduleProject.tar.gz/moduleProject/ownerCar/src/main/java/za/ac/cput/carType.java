package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class carType {
    public static char type(char t) throws Exception
    {
        return t;
    }
}
