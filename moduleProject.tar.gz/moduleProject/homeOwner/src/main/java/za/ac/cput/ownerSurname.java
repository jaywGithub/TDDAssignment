package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class ownerSurname {
    public static String surname(String snm) throws Exception
    {
        return snm;
    }
}
