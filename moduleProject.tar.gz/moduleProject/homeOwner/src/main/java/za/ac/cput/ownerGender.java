package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class ownerGender {
    public static String gender(String selection) throws Exception
    {
        return selection;
    }
}
