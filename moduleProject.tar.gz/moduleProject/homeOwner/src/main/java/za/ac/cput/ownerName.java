package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class ownerName {

    public static String name(String nm) throws Exception
    {
        return nm;
    }
}
