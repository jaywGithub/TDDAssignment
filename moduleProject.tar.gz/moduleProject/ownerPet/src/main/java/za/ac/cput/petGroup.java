package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class petGroup {
    public static String group(String gr) throws Exception
    {
        return gr;
    }
}
