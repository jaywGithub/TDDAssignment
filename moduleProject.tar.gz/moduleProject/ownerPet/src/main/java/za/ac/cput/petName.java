package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class petName {
    public static String name(String n) throws Exception
    {
        return n;
    }
}
