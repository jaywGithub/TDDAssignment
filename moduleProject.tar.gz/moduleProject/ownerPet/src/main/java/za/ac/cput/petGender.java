package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class petGender {
    public static char gender(char g)throws Exception
    {
        return g;
    }
}
