package za.ac.cput;

/**
 * Created by student on 2016/03/04.
 */
public class petAge {
    public static int age(int a)throws Exception
    {
        return a;
    }
}
