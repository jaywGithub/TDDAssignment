package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class notNullness {
    public static String personSurname(String surname)throws Exception
    {
        return surname;
    }
}
