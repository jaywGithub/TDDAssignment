package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class nullness {
    public static String personName(String name) throws Exception
    {
        return name;
    }
}
