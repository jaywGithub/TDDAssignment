package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class disabledTest {
    public static String musicNames(String songName) throws Exception
    {
        return songName;
    }
}
