package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class truth {
    public static boolean appleColour(String colour) throws Exception
    {
        colour = "red";
        boolean status = false;

        if(colour == "red")
            return status;
        else
            return true;
    }
}
