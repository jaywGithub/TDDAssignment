package za.ac.cput;

/**
 * Created by student on 2016/03/03.
 */
public class Integers {

    public static int intNum(int a, int b) throws Exception
    {
        return a + b;
    }
}