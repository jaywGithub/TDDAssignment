package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class failTest {
    public static int addition(int num1, int num2) throws Exception
    {
        return num1 + num2;
    }
}

