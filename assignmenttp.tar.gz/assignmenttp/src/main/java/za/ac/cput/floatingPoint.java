package za.ac.cput;

/**
 * Created by student on 2016/03/03.
 */
public class floatingPoint {

    public static float floatNum(float a, float b) throws Exception
    {
        return a + b;
    }
}