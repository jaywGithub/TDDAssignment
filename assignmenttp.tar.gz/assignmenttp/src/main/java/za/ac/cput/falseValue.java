package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class falseValue {
    public static boolean apple(String colour)throws Exception
    {
        colour = "red";
        boolean status = false;

        if(colour == "red")
            return status;
        else
            return true;
    }
}
