package za.ac.cput;

/**
 * Created by JAYSON on 2016-03-03.
 */
public class arrayContent {
    public static String[] list(String[] fruit)throws Exception
    {
        fruit = new String[]{"a", "b", "c", "d"};
        return fruit;
    }
}

